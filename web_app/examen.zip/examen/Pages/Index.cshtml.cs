using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using examen.Data;
using examen.Models;

namespace examen.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ApplicationDbContext context, ILogger<IndexModel> logger)
        {
            _context = context;
            _logger = logger;
        }

        public IList<Participant> Participanti { get; set; } = default!;
        public IList<Eveniment> Evenimente { get; set; } = default!;

        public async Task OnGetAsync()
        {
            Participanti = await _context.Participanti
                .Include(s => s.Eveniment)
                .ToListAsync();
            Evenimente = await _context.Evenimente.ToListAsync();
        }
    }
}
