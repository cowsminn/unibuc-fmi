﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using examen.Data;
using examen.Models;

namespace examen.Pages
{
    public class ParticipantDelete : PageModel
    {
        private readonly ILogger<ParticipantDelete> _logger;
        private readonly ApplicationDbContext _context;

        [BindProperty]
        public Participant? Participant { get; set; }

        public ParticipantDelete(ILogger<ParticipantDelete> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public async Task<IActionResult> OnGetAsync(int? id, string? token)
        {
            // If token is provided, try to parse it as base64 encoded ID
            if (!string.IsNullOrEmpty(token) && id == null)
            {
                try
                {
                    var bytes = Convert.FromBase64String(token);
                    id = BitConverter.ToInt32(bytes, 0);
                }
                catch
                {
                    return NotFound();
                }
            }

            if (id == null)
            {
                return NotFound();
            }

            Participant = await _context.Participanti
                .Include(p => p.Eveniment)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (Participant == null)
            {
                return NotFound();
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id, string? token)
        {
            // If token is provided, try to parse it as base64 encoded ID
            if (!string.IsNullOrEmpty(token) && id == null)
            {
                try
                {
                    var bytes = Convert.FromBase64String(token);
                    id = BitConverter.ToInt32(bytes, 0);
                }
                catch
                {
                    return NotFound();
                }
            }

            if (id == null)
            {
                return NotFound();
            }

            try
            {
                var concurentToDelete = await _context.Participanti.FindAsync(id);

                if (concurentToDelete != null)
                {
                    _context.Participanti.Remove(concurentToDelete);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "Participantul a fost șters cu succes!";
                }

                return RedirectToPage("./Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting concurent");
                TempData["ErrorMessage"] = "Eroare la ștergerea participantului: " + ex.Message;
                return RedirectToPage("./Index");
            }
        }
    }
}
