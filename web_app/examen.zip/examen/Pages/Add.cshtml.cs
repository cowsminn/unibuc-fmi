﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using examen.Data;
using examen.Models;

namespace examen.Pages
{
    public class ParticipantAdd : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<ParticipantAdd> _logger;

        public ParticipantAdd(ApplicationDbContext context, ILogger<ParticipantAdd> logger)
        {
            _context = context;
            _logger = logger;
        }

        [BindProperty]
        public Participant Participant { get; set; } = new Participant();

        public SelectList EvenimentList { get; set; } = new SelectList(new List<Eveniment>(), "Id", "titlu");

        public async Task<IActionResult> OnGetAsync()
        {
            await LoadEvenimenteAsync();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            _logger.LogInformation("OnPostAsync called. ModelState.IsValid: {IsValid}", ModelState.IsValid);


            // Validate EvenimentId is selected
            if (!Participant.EvenimentId.HasValue || Participant.EvenimentId.Value <= 0)
            {
                ModelState.AddModelError("Participant.EvenimentId", "Selectarea unui eveniment este obligatorie.");
            }

            if (!ModelState.IsValid)
            {
                _logger.LogWarning("ModelState is invalid");
                foreach (var error in ModelState)
                {
                    _logger.LogWarning("Key: {Key}, Errors: {Errors}", error.Key, string.Join(", ", error.Value.Errors.Select(e => e.ErrorMessage)));
                }
                await LoadEvenimenteAsync();
                return Page();
            }

            // Validare suplimentară pentru eveniment
            var eveniment = await _context.Evenimente
                .Include(c => c.Participanti)
                .FirstOrDefaultAsync(c => c.Id == Participant.EvenimentId!.Value);

            if (eveniment != null)
            {
                // Verifică dacă numărul maxim de concurenți a fost atins
                if (eveniment.Participanti.Count >= eveniment.nr_max_participanti)
                {
                    ModelState.AddModelError("Participant.EvenimentId",
                        $"Concursul a atins numărul maxim de {eveniment.nr_max_participanti} participanti.");
                    await LoadEvenimenteAsync();
                    return Page();
                }

                //// Verifică restricția de vârstă pentru minori
                //if (eveniment.necesita_invitatie && !Participant.EsteAdult)
                //{
                //    ModelState.AddModelError("Participant.EvenimentId",
                //        "Acest eveniment are restricție de vârstă. Doar adulții (18+ ani) pot participa.");
                //    await LoadEvenimenteAsync();
                //    return Page();
                //}
            }

            try
            {
                _logger.LogInformation("Adding participant: {nume} {prenume}", Participant.nume, Participant.prenume);
                _context.Participanti.Add(Participant);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = "Participantul a fost adăugat cu succes!";
                return RedirectToPage("./Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving participant");
                TempData["ErrorMessage"] = "Eroare la salvarea participantului: " + ex.Message;
                await LoadEvenimenteAsync();
                return Page();
            }
        }

        private async Task LoadEvenimenteAsync()
        {
            var evenimenturi = await _context.Evenimente.ToListAsync();
            EvenimentList = new SelectList(evenimenturi, "Id", "titlu");
        }
    }
}
