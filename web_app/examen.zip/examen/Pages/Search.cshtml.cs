using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using examen.Data;
using examen.Models;

namespace examen.Pages
{
    public class EvenimentSearch : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<EvenimentSearch> _logger;

        public EvenimentSearch(ApplicationDbContext context, ILogger<EvenimentSearch> logger)
        {
            _context = context;
            _logger = logger;
        }

        [BindProperty(SupportsGet = true)]
        public string? Searchtitlu { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? Searchtip_eveniment { get; set; }

        [BindProperty(SupportsGet = true)]
        public int? SearchZi { get; set; }

        [BindProperty(SupportsGet = true)]
        public int? SearchLuna { get; set; }

        [BindProperty(SupportsGet = true)]
        public int? SearchAn { get; set; }

        public IList<Eveniment> Evenimente { get; set; } = new List<Eveniment>();
        public List<string> tip_eveniment { get; set; } = new List<string>();
        public bool HasSearched { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            // Load available categories
            tip_eveniment = await _context.Evenimente
                .Where(c => !string.IsNullOrEmpty(c.tip_eveniment))
                .Select(c => c.tip_eveniment)
                .Distinct()
                .OrderBy(c => c)
                .ToListAsync();

            // Store search values for view
            ViewData["SearchZi"] = SearchZi?.ToString();
            ViewData["SearchLuna"] = SearchLuna?.ToString();
            ViewData["SearchAn"] = SearchAn?.ToString();

            // Check if any search parameters are provided
            HasSearched = !string.IsNullOrEmpty(Searchtitlu) ||
                         SearchZi.HasValue ||
                         SearchLuna.HasValue ||
                         SearchAn.HasValue ||
                         !string.IsNullOrEmpty(Searchtip_eveniment);

            // Always perform search - if no criteria, show all
            await PerformSearchAsync();

            return Page();
        }

        private async Task PerformSearchAsync()
        {
            var query = _context.Evenimente
                .Include(c => c.Participanti)
                .AsQueryable();

            // Only apply filters if search criteria are provided
            if (!string.IsNullOrEmpty(Searchtitlu))
            {
                query = query.Where(c => c.titlu.Contains(Searchtitlu));
            }

            if (SearchZi.HasValue)
            {
                query = query.Where(c => c.data.Day == SearchZi.Value);
            }

            if (SearchLuna.HasValue)
            {
                query = query.Where(c => c.data.Month == SearchLuna.Value);
            }

            if (SearchAn.HasValue)
            {
                query = query.Where(c => c.data.Year == SearchAn.Value);
            }

            if (!string.IsNullOrEmpty(Searchtip_eveniment))
            {
                query = query.Where(c => c.tip_eveniment.Contains(Searchtip_eveniment));
            }

            Evenimente = await query
                .OrderBy(c => c.data)
                .ThenBy(c => c.titlu)
                .ToListAsync();

            _logger.LogInformation("Search performed. Found {Count} contests matching criteria", Evenimente.Count);
        }

        public IActionResult OnPostClearAsync()
        {
            return RedirectToPage("./EvenimenteSearch");
        }
    }
}
