﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using examen.Data;
using examen.Models;

namespace examen.Pages
{
    public class ParticipantEdit : PageModel
    {
        private readonly ILogger<ParticipantEdit> _logger;
        private readonly ApplicationDbContext _context;

        [BindProperty]
        public Participant? Participant { get; set; }

        public SelectList? EvenimentList { get; set; }

        public ParticipantEdit(ILogger<ParticipantEdit> logger, ApplicationDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public async Task<IActionResult> OnGetAsync(int? id, string? token)
        {
            // If token is provided, try to parse it as base64 encoded ID
            if (!string.IsNullOrEmpty(token) && id == null)
            {
                try
                {
                    var bytes = Convert.FromBase64String(token);
                    id = BitConverter.ToInt32(bytes, 0);
                }
                catch
                {
                    return NotFound();
                }
            }

            if (id == null)
            {
                return NotFound();
            }

            Participant = await _context.Participanti
                .Include(p => p.Eveniment)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (Participant == null)
            {
                return NotFound();
            }

            EvenimentList = new SelectList(await _context.Evenimente.ToListAsync(), "Id", "titlu", Participant.EvenimentId);

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            _logger.LogInformation("OnPostAsync called. ModelState.IsValid: {IsValid}", ModelState.IsValid);

            // Validate EvenimentId is selected
            if (Participant != null && (!Participant.EvenimentId.HasValue || Participant.EvenimentId.Value <= 0))
            {
                ModelState.AddModelError("Participant.EvenimentId", "Selectarea unui eveniment este obligatorie.");
            }

            if (!ModelState.IsValid || Participant == null)
            {
                _logger.LogWarning("ModelState is invalid or Participant is null");
                foreach (var error in ModelState)
                {
                    _logger.LogWarning("Key: {Key}, Errors: {Errors}", error.Key, string.Join(", ", error.Value.Errors.Select(e => e.ErrorMessage)));
                }
                EvenimentList = new SelectList(await _context.Evenimente.ToListAsync(), "Id", "titlu", Participant?.EvenimentId);
                return Page();
            }

            var participantToUpdate = await _context.Participanti
                .Include(c => c.Eveniment)
                .FirstOrDefaultAsync(c => c.Id == Participant.Id);

            if (participantToUpdate == null)
            {
                return NotFound();
            }

            //// Verifică dacă modificarea vârstei ar face participantul minor când este înscris la un eveniment 18+
            //if (participantToUpdate.Eveniment != null && participantToUpdate.Eveniment.RestrictieVarsta)
            //{
            //    if (!Participant.EsteAdult)
            //    {
            //        ModelState.AddModelError("Participant.DataNasterii",
            //            $"Nu puteți modifica vârsta pentru a face participantul minor când este înscris la evenimentul '{participantToUpdate.Eveniment.Nume}' care are restricție de vârstă 18+. " +
            //            "Eliminați mai întâi participantul din acest eveniment sau alegeți o dată de naștere care să mențină statutul de adult.");
            //        EvenimentList = new SelectList(await _context.Evenimente.ToListAsync(), "Id", "Nume", Participant?.EvenimentId);
            //        return Page();
            //    }
            //}

            // Validare suplimentară pentru eveniment (doar dacă se schimbă evenimentul)
            if (Participant.EvenimentId.HasValue && Participant.EvenimentId != participantToUpdate.EvenimentId)
            {
                var eveniment = await _context.Evenimente
                    .Include(c => c.Participanti)
                    .FirstOrDefaultAsync(c => c.Id == Participant.EvenimentId.Value);

                if (eveniment != null)
                {
                    // Verifică dacă numărul maxim de participanti a fost atins
                    if (eveniment.Participanti.Count >= eveniment.nr_max_participanti)
                    {
                        ModelState.AddModelError("Participant.EvenimentId",
                            $"Evenimentul a atins numărul maxim de {eveniment.nr_max_participanti} participanti.");
                        EvenimentList = new SelectList(await _context.Evenimente.ToListAsync(), "Id", "titlu", Participant?.EvenimentId);
                        return Page();
                    }

                    //// Verifică restricția de vârstă pentru minori
                    //if (eveniment.RestrictieVarsta && !Participant.EsteAdult)
                    //{
                    //    ModelState.AddModelError("Participant.EvenimentId",
                    //        "Acest eveniment are restricție de vârstă. Doar adulții (18+ ani) pot participa.");
                    //    EvenimentList = new SelectList(await _context.Evenimente.ToListAsync(), "Id", "Nume", Participant?.EvenimentId);
                    //    return Page();
                    //}
                }
            }

            // Actualizează proprietățile
            participantToUpdate.nume = Participant.nume;
            participantToUpdate.prenume = Participant.prenume;
            participantToUpdate.email = Participant.email;
            participantToUpdate.tara = Participant.tara;
            participantToUpdate.EvenimentId = Participant.EvenimentId;

            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Participantul a fost actualizat cu succes!";
            return RedirectToPage("./Index");
        }
    }
}
