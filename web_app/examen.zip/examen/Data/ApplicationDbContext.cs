﻿using Microsoft.EntityFrameworkCore;
using examen.Models;

namespace examen.Data
{
    public class ApplicationDbContext : DbContext
    {

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Eveniment> Evenimente { get; set; }
        public DbSet<Participant> Participanti { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Participant>()
                .HasOne(p => p.Eveniment)
                .WithMany(e => e.Participanti)
                .HasForeignKey(p => p.EvenimentId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
