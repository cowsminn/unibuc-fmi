﻿using System.ComponentModel.DataAnnotations;

namespace examen.Models
{
    public class Eveniment
    {
        public int Id { get; set; }

        [Required]
        public String titlu { get; set; } = string.Empty;

        [Required]
        public DateTime data {  get; set; }

        [Required]
        public string locatie { get; set; } = string.Empty;

        [Required]
        public string tip_eveniment { get; set; } = string.Empty;

        [Required]
        public int nr_max_participanti { get; set; }

        [Required]
        public bool necesita_invitatie { get; set; }

        public virtual ICollection<Participant> Participanti { get; set; } = new List<Participant>();

    }
}
