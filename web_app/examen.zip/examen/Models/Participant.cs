﻿using System.ComponentModel.DataAnnotations;

namespace examen.Models

{
    public class Participant
    {

        public int Id { get; set; }

        [Required]
        public string nume { get; set; } = string.Empty;

        [Required]
        public string prenume { get; set; } = string.Empty;

        [Required]
        public string email {  get; set; } = string.Empty;

        [Required]
        public string tara {  get; set; } = string.Empty;

        [Required]
        public int? EvenimentId { get; set; }

        public virtual Eveniment? Eveniment { get; set; }

    }
}
